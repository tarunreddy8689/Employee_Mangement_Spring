package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class employee_service {
	
	@Autowired
	employee_repository employee_repo;
	
	public List<employee_database> getAllEmployees() {
		// TODO Auto-generated method stub
		return employee_repo.findAll();	
	}

	public employee_database getEmployee(int id) {
		// TODO Auto-generated method stub
		return employee_repo.findById(id).orElse(null);
	}

	public employee_database addEmployee(employee_database employee) {
		// TODO Auto-generated method stub
		return employee_repo.save(employee);
	}

	public void deleteEmployee(int employee_id) {
		// TODO Auto-generated method stub
		employee_repo.deleteById(employee_id);
	}

}
