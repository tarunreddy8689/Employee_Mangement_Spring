package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface employee_repository extends JpaRepository<employee_database, Integer> {

}
