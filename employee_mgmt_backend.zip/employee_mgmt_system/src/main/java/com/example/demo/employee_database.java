package com.example.demo;

import java.sql.Date;
import java.util.*;

public class employee_database {
	int id;
	String name;
	String address;
	String designation;
	Date dob;
	String gender;
	public employee_database(int id, String name, String address, String designation, Date dob, String gender) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.designation = designation;
		this.dob = dob;
		this.gender = gender;
	}
	public employee_database(String name, String address, String designation, Date dob, String gender) {
		super();
		this.name = name;
		this.address = address;
		this.designation = designation;
		this.dob = dob;
		this.gender = gender;
	}
	
	public employee_database() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
}
