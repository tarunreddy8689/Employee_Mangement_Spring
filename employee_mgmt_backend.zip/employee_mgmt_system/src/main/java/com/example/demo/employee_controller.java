package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
@RequestMapping("/emp_mgmt")
public class employee_controller {
	
	@Autowired
	employee_service emp_service;
	
	@GetMapping("/getallemployees")
	public List<employee_database> getAllEmployees() {
		return emp_service.getAllEmployees();
	}
	
	@GetMapping("/getemployee")
	public employee_database getEmployeebyid(@RequestParam("Employee_id") int id) {
		return emp_service.getEmployee(id);
	}
	
	@PostMapping("/addemployee")
	public employee_database addEmployee(@RequestBody employee_database employee) {
		return emp_service.addEmployee(employee);
	}
	
	@DeleteMapping("/delete_employee")
	public String delete_employee(@RequestParam("Employee_id") int Employee_id) {
		emp_service.deleteEmployee(Employee_id);
		return "employee deleted successfully";
	}
	
}
